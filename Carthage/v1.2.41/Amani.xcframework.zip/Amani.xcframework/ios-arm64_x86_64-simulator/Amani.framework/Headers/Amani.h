//
//  Amani.h
//  Amani
//
//  Created by Daffolapmac-169 on 13/12/20.
//  Copyright © 2020 Daffolapmac-169. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Amani.
FOUNDATION_EXPORT double AmaniVersionNumber;

//! Project version string for Amani.
FOUNDATION_EXPORT const unsigned char AmaniVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Amani/PublicHeader.h>

//#import <Amani/CvVideoCameraWrapper.h>
//#import <Amani/OpenSSL.h>
