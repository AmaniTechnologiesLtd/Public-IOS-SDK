//
//  AmaniBioMatch.h
//  AmaniBioMatch
//
//  Created by Bedri Doğan on 20.08.2025.
//

#import <Foundation/Foundation.h>

//! Project version number for AmaniBioMatch.
FOUNDATION_EXPORT double AmaniBioMatchVersionNumber;

//! Project version string for AmaniBioMatch.
FOUNDATION_EXPORT const unsigned char AmaniBioMatchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmaniBioMatch/PublicHeader.h>


