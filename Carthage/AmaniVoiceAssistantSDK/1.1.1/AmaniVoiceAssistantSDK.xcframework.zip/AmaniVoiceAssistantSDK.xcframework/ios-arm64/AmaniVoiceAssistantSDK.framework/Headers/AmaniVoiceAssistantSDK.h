//
//  AmaniVoiceAssistantSDK.h
//  AmaniVoiceAssistantSDK
//
//  Created by Münir Ketizmen on 18.12.2024.
//

#import <Foundation/Foundation.h>

//! Project version number for AmaniVoiceAssistantSDK.
FOUNDATION_EXPORT double AmaniVoiceAssistantSDKVersionNumber;

//! Project version string for AmaniVoiceAssistantSDK.
FOUNDATION_EXPORT const unsigned char AmaniVoiceAssistantSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmaniVoiceAssistantSDK/PublicHeader.h>


